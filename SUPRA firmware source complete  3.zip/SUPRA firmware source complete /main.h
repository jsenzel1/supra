extern int masterSeed;
